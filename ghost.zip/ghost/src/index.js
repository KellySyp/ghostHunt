import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import Board from './components/board';


class App extends Component {
	constructor(props){
		super(props);
		
		this.state = {
			width: 8,
			height: 8,
			ghosts: 10
		};
	};
	
	render(){
		return(
			<div>
				<Board 
					height = {this.state.height}
					width= {this.state.width}
					ghosts = {this.state.ghosts}
				/>
			</div>
		)
	}
}

//Take this component's generated HTML and put it in DOM - On the page
ReactDOM.render(<App />, document.querySelector('.container'));