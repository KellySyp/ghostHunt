import React, { Component } from 'react';
import Cell from './cell';


class Board extends Component {
	constructor(props){
		super(props);
		
		this.state = {
			ghostCount: this.props.ghosts,
			data: []
		};
		
	}
	
	createBoard(){
	//Create Array
		let data = [];
		
		for(let i = 0; i < this.props.height; i++){
			data.push([]);
			for(let j = 0; j < this.props.width; j++){
				data[i][j] = {
					x: i,
                    y: j,
					value: 0,
					className: 'graveClosed'
				}
			}
		}
	//Hide Ghosts
	
	for(let i =0; i < this.state.ghostCount ; i++){
		var rdmX = this.getRandomNumber(this.props.width);
		var rdmY = this.getRandomNumber(this.props.height);
		data[rdmX][rdmY].value = 9;
	}
	
	//Check Neighbors
	for(let i = 0; i < this.props.height; i++){
			for(let j = 0; j < this.props.width; j++){
				let neighborCount = 0;
				if(data[i][j].value < 9){
					
					if(i>0 && j > 0 && data[i-1][j-1].value == 9){
						neighborCount++;
					}
					if(i > 0 && data[i-1][j].value == 9){
						neighborCount++;
					}
					if(i > 0 && j < this.props.width-1 && data[i-1][j+1].value == 9){
						neighborCount++;
					}
					if(j > 0 && data[i][j-1].value == 9){
						neighborCount++;
					}
					if(j < this.props.width-1 && data[i][j+1].value == 9){
						neighborCount++;
					}
					if(i < this.props.height-1 && j > 0 && data[i+1][j-1].value == 9){
						neighborCount++;
					}
					if(i < this.props.height-1 && data[i+1][j].value == 9){
						neighborCount++;
					}
					if(i < this.props.height-1 && j < this.props.width-1 && data[i+1][j+1].value == 9){
						neighborCount++;
					} 
					
					data[i][j].value = neighborCount;
					
				}
				
			}
		}
	
	//Return Cells
		return data.map((datarow)=>{
			return datarow.map((dataitem)=>{
				return(
					<Cell 
						key = {dataitem.x +""+ dataitem.y}
						data = {dataitem}
						className = {dataitem.className}
						onClick={() => this.checkCell(dataitem)}
					/>
				);
			});
		});
	}
	
	checkCell(data){
		data.className = 'graveOpen';
	}
	
	// get random number given a dimension
    getRandomNumber(dimension) {
        // return Math.floor(Math.random() * dimension);
        return Math.floor((Math.random() * 1000) + 1) % dimension;
    }
	

	render(){
		return(
			<div className = "Board">
				{
                    this.createBoard()
                }
			</div>
		)
	}
	
}


export default Board;